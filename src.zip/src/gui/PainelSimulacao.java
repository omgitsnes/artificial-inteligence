package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JPanel;

import agentereativo.*;
import java.awt.CardLayout;
import javax.swing.SwingWorker;

public class PainelSimulacao extends JPanel implements AmbienteListener{
	
    public static final int TAMANHO_CELULA = 20;
    public static final int GRID_TO_PANEL_GAP = 20;
    public static final int N = 8;
	
    private Ambiente ambiente;
    private Image imagem;
	
    JPanel painelAmbiente = new JPanel();    
    JButton jButtonIniciar = new JButton("Iniciar");

    public PainelSimulacao() {
        painelAmbiente.setPreferredSize(new Dimension(N * TAMANHO_CELULA + GRID_TO_PANEL_GAP * 2, N * TAMANHO_CELULA + GRID_TO_PANEL_GAP * 2));
        setLayout(new BorderLayout());
        add(painelAmbiente, java.awt.BorderLayout.CENTER);
        add(jButtonIniciar, java.awt.BorderLayout.SOUTH);
        jButtonIniciar.addActionListener(new PainelSimulacao_jButtonIniciar_actionAdapter(this));
    }

    	
    public void jButtonIniciar_actionPerformed(ActionEvent e) {
        ambiente = new Ambiente();
        ambiente.addAmbienteListener(this);

        criarImagem(ambiente);

        SwingWorker worker = new SwingWorker<Void, Void>(){
            public Void doInBackground(){                
                ambienteAtualizado();
                ambiente.evoluir();
                return null;
            }
        };
        worker.execute();
    }
           
    public void criarImagem(Ambiente ambiente){
        imagem = new BufferedImage(ambiente.getNumColunas() * TAMANHO_CELULA, ambiente.getNumLinhas() * TAMANHO_CELULA, BufferedImage.TYPE_INT_RGB);
    }

    
    public void ambienteAtualizado() {
        int n = ambiente.getNumLinhas();
        Graphics g = imagem.getGraphics();
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                g.setColor(ambiente.getCorCelula(y, x));
                g.fillRect(x * TAMANHO_CELULA, y * TAMANHO_CELULA, TAMANHO_CELULA, TAMANHO_CELULA);
            }
        }
        g = painelAmbiente.getGraphics();
        g.drawImage(imagem, GRID_TO_PANEL_GAP, GRID_TO_PANEL_GAP, null);

        try{
           Thread.sleep(1000);
        }catch(InterruptedException ignore){
        }
    }
}

//--------------------

class PainelSimulacao_jButtonIniciar_actionAdapter implements ActionListener {
    private PainelSimulacao adaptee;
    PainelSimulacao_jButtonIniciar_actionAdapter(PainelSimulacao adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jButtonIniciar_actionPerformed(e);
    }
}
