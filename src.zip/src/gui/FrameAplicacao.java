package gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class FrameAplicacao extends JFrame{

    public static final long serialVersionUID = 1;
    
    PainelSimulacao painelSimulacao = new PainelSimulacao();
    
    public FrameAplicacao() {
           	
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    	setTitle("Agentes Reactivos (c) Inteligência Artificial - Engenharia Informática - ESTG/IPL");

        //Menus
        JMenuBar jMenuBar1 = new JMenuBar();
        setJMenuBar(jMenuBar1);        
        JMenu jMenuFile = new JMenu("Menu");
        jMenuBar1.add(jMenuFile);        
        JMenuItem jMenuFileExit = new JMenuItem("Sair");
        jMenuFile.setMnemonic('M');
        jMenuFileExit.addActionListener(new FrameAplicacao_jMenuFileSair_ActionAdapter(this));
        jMenuFile.add(jMenuFileExit);
                              
        //Global structure 
        JPanel contentPane = (JPanel) getContentPane();
        contentPane.add(painelSimulacao, BorderLayout.CENTER);
        pack();              
    }


    void jMenuFileSair_actionPerformed(ActionEvent actionEvent) {
        System.exit(0);
    }

    
    public void showError(String message){
        JOptionPane.showMessageDialog(this, message, "Erro!", JOptionPane.ERROR_MESSAGE);
    }
}


class FrameAplicacao_jMenuFileSair_ActionAdapter implements ActionListener {
    FrameAplicacao adaptee;

    FrameAplicacao_jMenuFileSair_ActionAdapter(FrameAplicacao adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent actionEvent) {
        adaptee.jMenuFileSair_actionPerformed(actionEvent);
    }
}
