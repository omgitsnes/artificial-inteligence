package agentereativo;

import java.awt.Color;
import java.util.ArrayList;

public class Ambiente {
    private Celula[][] grelha;
    private AgenteReativo agente;


    public Ambiente(){
        grelha = new Celula[8][8];
        for(int i = 0; i < grelha.length; i++)
            for(int j = 0; j < grelha[0].length; j++)
                grelha[i][j] = new Celula(i, j);
        grelha[2][2].setParede(new Parede());
        grelha[2][3].setParede(new Parede());
        grelha[2][4].setParede(new Parede());
        grelha[5][2].setParede(new Parede());

        agente = new AgenteReativo(getCelula(6, 3));
    }


    public void evoluir(){
    	agente.agir(this);
        fireAmbienteActualizado();        
    }


    public void setAgente(AgenteReativo agenteReativo) {
        this.agente = agenteReativo;
    }


    public AgenteReativo getAgente() {
        return agente;
    }


    public int getNumLinhas(){
        return grelha.length;
    }


    public int getNumColunas(){
        return grelha[0].length;
    }


    public Celula getCelula(int linha, int coluna) {
        return grelha[linha][coluna];
    }


    public Color getCorCelula(int linha, int coluna) {
            return grelha[linha][coluna].getCor();
    }


    public Celula getCelulaNorte(Celula Celula) {
        if (Celula.getLinha() > 0)
            return grelha[Celula.getLinha() - 1][Celula.getColuna()];
        return null;
    }


    public Celula getCelulaSul(Celula celula) {
        if (celula.getLinha() < grelha.length - 1)
            return grelha[celula.getLinha() + 1][celula.getColuna()];
        return null;
    }


    public Celula getCelulaEste(Celula celula) {
        if (celula.getColuna() > 0)
            return grelha[celula.getLinha()][celula.getColuna() - 1];
        return null;
    }


    public Celula getCelulaOeste(Celula celula) {
        if (celula.getColuna() < grelha[0].length - 1)
            return grelha[celula.getLinha()][celula.getColuna() + 1];
        return null;
    }
    

    @Override
    public String toString(){
        StringBuilder s = new StringBuilder("Ambiente:\n");
        for (int i = 0; i < grelha.length; i++) {
            for (int j = 0; j < grelha[0].length; j++) {
                if(grelha[i][j].temParede())
                    s.append('X');
                else
                if(grelha[i][j].temAgente())
                    s.append('A');
                else
                    s.append('.');
            }
            s.append('\n');
        }
        return s.toString();
    }


    
    //listeners

    private ArrayList<AmbienteListener> listeners = new ArrayList<AmbienteListener>();

    public synchronized void addAmbienteListener(AmbienteListener l) {
        if (!listeners.contains(l)){
        	listeners.add(l);
        }
    }


    public void fireAmbienteActualizado(){
    	for(AmbienteListener listener: listeners)
    		listener.ambienteAtualizado();
    }
}