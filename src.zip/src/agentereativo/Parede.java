package agentereativo;

import java.awt.Color;

public class Parede {

    public Color getCor(){
        return Color.BLUE;
    }

}