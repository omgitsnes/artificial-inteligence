package agentereativo;

public class Acao {
    public static final Acao NORTE = new Acao("Norte");
    public static final Acao SUL = new Acao("Sul");
    public static final Acao ESTE = new Acao("Este");
    public static final Acao OESTE = new Acao("Oeste");

    private String descricao;

    
    public Acao(String descricao){
        this.descricao = descricao;
    }


    @Override
    public String toString() {
        return descricao;
    }
}