package agentereativo;

public class Percecao {
    private Celula N, S, E, O;


    public Percecao(Celula N, Celula S, Celula E, Celula O){
        this.N = N;
        this.S = S;
        this.E = E;
        this.O = O;
    }


    public Celula getE() {
        return E;
    }


    public Celula getN() {
        return N;
    }


    public Celula getO() {
        return O;
    }


    public Celula getS() {
        return S;
    }
}