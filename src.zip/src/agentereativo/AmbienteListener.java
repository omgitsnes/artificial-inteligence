package agentereativo;


public interface AmbienteListener {
	
    void ambienteAtualizado();
}
