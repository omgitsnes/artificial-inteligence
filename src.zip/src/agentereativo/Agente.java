package agentereativo;


public interface Agente {

  public void agir(Ambiente ambiente);

}