package agentereativo;

import java.awt.Color;

public class AgenteReativo implements Agente{
    private Celula celula;


    public AgenteReativo(Celula celula){
        this.celula = celula;
        this.celula.setAgente(this);
    }


    public void agir(Ambiente ambiente){
        for(int i = 0; i < 20; i++){
            executar(decidir(construirPercecao(ambiente)), ambiente);
            ambiente.fireAmbienteActualizado();
        }
    }


    public Celula getQuadricula() {
        return celula;
    }


    public void setQuadricula(Celula quadricula) {
        this.celula.setAgente(null);
        this.celula = quadricula;
        this.celula.setAgente(this);
    }


    private Percecao construirPercecao(Ambiente ambiente){
        return new Percecao(
            ambiente.getCelulaNorte(celula),
            ambiente.getCelulaSul(celula),
            ambiente.getCelulaEste(celula),
            ambiente.getCelulaOeste(celula));
    }


    private Acao decidir(Percecao percecao){

        if(true) return Acao.NORTE;
        return null;
    }


    private void executar(Acao acao, Ambiente ambiente){
        Celula destino = null;
        if(acao == Acao.NORTE && celula.getLinha() != 0)
            destino = ambiente.getCelulaNorte(celula);
        else
        if(acao == Acao.SUL && celula.getLinha() != ambiente.getNumLinhas())
            destino = ambiente.getCelulaSul(celula);
        else
        if(acao == Acao.ESTE && celula.getColuna() != 0)
            destino = ambiente.getCelulaEste(celula);
        else
        if(acao == Acao.OESTE && celula.getColuna() != ambiente.getNumColunas())
            destino = ambiente.getCelulaOeste(celula);

        if(destino != null && !destino.temParede())
            setQuadricula(destino);
    }

    public Color getCor(){
        return Color.BLACK;
    }
}