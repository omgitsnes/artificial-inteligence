package agentereativo;

import java.awt.Color;

public class Celula {
    private int linha, coluna;
    private AgenteReativo agente;
    private Parede parede;


    public Celula(int linha, int coluna){
        this.linha = linha;
        this.coluna = coluna;
    }


    public AgenteReativo getAgente() {
        return agente;
    }


    public void setAgente(AgenteReativo agente) {
        this.agente = agente;
    }


    public boolean temAgente() {
        return agente != null;
    }


    public Parede getParede() {
        return parede;
    }


    public void setParede(Parede parede) {
        this.parede = parede;
    }


    public boolean temParede() {
        return parede != null;
    }


    public int getLinha() {
        return linha;
    }


    public int getColuna() {
        return coluna;
    }


    public Color getCor(){
        if(agente != null)
            return agente.getCor();
        if(parede != null)
            return parede.getCor();
        return Color.WHITE;

    }
}